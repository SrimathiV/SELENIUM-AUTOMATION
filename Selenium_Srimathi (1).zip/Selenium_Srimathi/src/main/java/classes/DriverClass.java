package classes;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.util.concurrent.TimeUnit;
public class DriverClass {
    private static DriverClass driverClass;
    private WebDriver driver;
    private DriverClass(){
        System.setProperty("webdriver.gecko.driver", "/Users/srimathi/Downloads/geckodriver");
        driver = new FirefoxDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.get("https://www.flipkart.com/?s_kwcid=AL!739!3!582822043916!e!!g!!flipkart&gclsrc=aw.ds&&semcmpid=sem_8024046704_brand_exe_buyers_goog&gclid=Cj0KCQjw_viWBhD8ARIsAH1mCd5Nv8o-IHc6r18a7SRRKSzpHEJTHD6-AZWdWWvKWMN5k39r9SMFaVgaAqslEALw_wcB");
    }
    public static DriverClass getInstanceOfDriverClass(){
        return new DriverClass();
    }
    public WebDriver getDriver(){
        return driver;
    }
}
