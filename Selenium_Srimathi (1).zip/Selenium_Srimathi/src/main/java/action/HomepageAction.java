package action;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import page.HomePage;

public class HomepageAction {

    public HomePage homePage;
    public WebDriver driver;


    public HomepageAction(WebDriver driver) {
        homePage = PageFactory.initElements(driver, HomePage.class);
        this.driver = driver;
    }




    public void clickmobiles() {
        homePage.clickOnMobile();
    }

    public void clickelectronics()
    {
        homePage.clickOnElectronics();
    }

    public void clickinfinix()
    {
        homePage.clickOnInfinix();
    }
    public void clickhot12play()
    {
        homePage.clickOnHotInfinix12();
    }

    public void clickbuy() throws InterruptedException {
        homePage.clickOnBuyNow();

    }


//    public void clickfashion()
//    {
//        homePage.clickOnFashion();
//    }
//
//    public void clickelectronics()
//    {
//        homePage.clickOnElectronics();
//    }
//
//    public void clickbeauty()
//    {
//        homePage.clickOnBeauty();
//    }
//
//    public void clickhome()
//    {
//        homePage.clickOnHome();
//    }
//
//    public void clicklarge()
//    {
//        homePage.clickOnLarge();
//    }
//    public void clickfurniture()
//    {
//        homePage.clickOnFurniture();
//    }
}