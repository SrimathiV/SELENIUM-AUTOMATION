package steps;

import action.HomepageAction;
import classes.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;

public class Stepdefs extends BaseClass {
    WebDriver driver;
    public  Stepdefs(){
        super();
        driver=getDriver();
    }
    @Given("The user is in home page")
    public void theUserNavigatesToHomePage() {

        HomepageAction actions= new HomepageAction(driver);
        actions.clickmobiles();
    }

    @Given("The user selects category")
    public void theUserSelectsCategory() {
        HomepageAction actions= new HomepageAction(driver);
        actions.clickelectronics();
    }

    @When("Click on Mobile Category")
    public void clickOnMobileCategory() {
        HomepageAction actions= new HomepageAction(driver);
        actions.clickinfinix();
    }

    @And("Click on one brand")
    public void clickOnOneBrand() {
        HomepageAction actions= new HomepageAction(driver);
        actions.clickhot12play();

    }



    @Then("click buy now")
    public void clickBuyNow() {
    }
}
