package page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage {
    WebDriver driver;

    public HomePage(WebDriver webDriver){
        driver=webDriver;

    }
    @FindBy (xpath="//img[contains(@alt,'Mobiles')]")

    WebElement mobile;

    @FindBy(xpath = "//span[contains(text(),'Electronics')]")
    WebElement electronics;

    @FindBy(xpath = "//a[contains(text(),'Infinix')]")
    WebElement infinix;
    @FindBy(xpath = "//div[@class='_4rR01T']")
    WebElement infinix12;

    @FindBy(xpath = "//span[contains(text(),'BUY NOW')]")
    WebElement buy;


//    @FindBy(xpath = "//div[contains(text(),'Fashion')]")
//    WebElement fashion;
//
//
//    @FindBy(xpath = "//div[contains(text(),'Electronics')]")
//    WebElement electronics;
//
//    @FindBy(xpath = "//div[contains(text(),'Beauty')]")
//    WebElement beauty;
//
//
//
//    @FindBy(xpath = "//div[contains(text(),'Home')]")
//    WebElement home;
//
//    @FindBy(xpath = "//div[contains(text(),'Large')]")
//    WebElement large;
//
//    @FindBy(xpath = "//div[contains(text(),'Furniture')]")
//    WebElement furniture;


    public void clickOnMobile(){

        mobile.click();
    }
    public void clickOnElectronics()
    {
        electronics.click();
    }

    public void clickOnInfinix()
    {
        infinix.click();
    }

    public void clickOnHotInfinix12()
    {
        infinix12.click();
    }

    public void clickOnBuyNow() throws InterruptedException {

        buy.click();
        Thread.sleep(5000);
    }

//    public void clickOnFashion(){
//
//        fashion.click();
//    }
//
//    public void clickOnElectronics(){
//
//        electronics.click();
//    }
//
//    public void clickOnBeauty(){
//
//        beauty.click();
//    }
//
//    public void clickOnHome(){
//
//        home.click();
//    }
//
//    public void clickOnLarge(){
//
//        large.click();
//    }
//
//    public void clickOnFurniture(){
//
//        furniture.click();
//    }

//    public void clickMobile() {
//        mobile.click();
//    }



}
