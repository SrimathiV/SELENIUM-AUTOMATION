package base;

import action.HomepageAction;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class Main {


    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdriver.gecko.driver", "/Users/srimathi/Downloads/geckodriver");
        WebDriver driver;
        driver = new FirefoxDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.get("https://www.flipkart.com/?s_kwcid=AL!739!3!582822043916!e!!g!!flipkart&gclsrc=aw.ds&&semcmpid=sem_8024046704_brand_exe_buyers_goog&gclid=Cj0KCQjw_viWBhD8ARIsAH1mCd5Nv8o-IHc6r18a7SRRKSzpHEJTHD6-AZWdWWvKWMN5k39r9SMFaVgaAqslEALw_wcB");
        HomepageAction actions= new HomepageAction(driver);
        Thread.sleep(3000);
        actions.clickmobiles();
//        actions.clickfashion();
//        actions.clickelectronics();
//        actions.clickbeauty();
//        actions.clickhome();
//        actions.clicklarge();
//        actions.clickfurniture();
        actions.clickelectronics();
        actions.clickinfinix();
        actions.clickhot12play();

        String parent = driver.getWindowHandle();
        Set<String> s = driver.getWindowHandles();
        Iterator<String> I1 = s.iterator();
        while (I1.hasNext()) {
                     String child_window = I1.next();
            if (!parent.equals(child_window)) {
                driver.switchTo().window(child_window);
                actions.clickbuy();
                Thread.sleep(4000);
            }
       }






    }
}